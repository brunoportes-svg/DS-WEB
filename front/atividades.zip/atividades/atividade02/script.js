
   

    function imagem1(){
    document.getElementById("foto").setAttribute("src", "cristiano.jpg")  
    }


    function imagem2(){
    document.getElementById("foto").setAttribute("src", "messi.jpg")
    }
